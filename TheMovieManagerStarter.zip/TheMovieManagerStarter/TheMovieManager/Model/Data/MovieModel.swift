//
//  MovieModel.swift
//  TheMovieManager
//
//  Created by Owen LaRosa on 8/13/18.
//  Copyright © 2018 Udacity. All rights reserved.
//

import Foundation

class MovieModel {
    
    static var watchlist = [Movie]()
    static var favorites = [Movie]()
    
}
